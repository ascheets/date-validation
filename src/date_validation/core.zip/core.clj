(ns date-validation.core)

(import '(javax.swing JOptionPane))

(use '[clojure.string :only (join split)])

(defrecord Date[day month year])

(def daysInMonths {1 31 2 28 3 31 4 30 5 31 6 30 7 31 8 31 9 30 10 31 11 30 12 31})

(defn leapYear [year]
    
  (cond
    (= (mod year 4) 0) true
    (= (mod year 1000) 0) true
    :else false)
)

(defn validDay [date]

  (def splitDate
    (split date #"/")
    )

  (def month (. Integer parseInt (nth splitDate 0)))
  (def day (. Integer parseInt (nth splitDate 1)))
  (def year (. Integer parseInt (nth splitDate 2)))
  
  (if (and (validMonth month) (validYear year))
    ;;if the month and year are valid
    (do
      (if (and (leapYear year) (= month 2))
        ;;if leap year and february
        (do
          ;;(println "leap year, feb")
          ;; if valid day
          (cond
            (<= day 0) false
            (> day 29) false
            :else true
            )
          )
        ;;else
        (do
          ;;if not leap year
          ;;(println "not leap year")
          (cond
            (<= day 0) false
            (> day (daysInMonths month)) false
            :else true
            )
          )
        )
      )
    )
  )

(defn validMonth [month]

  (cond
    (<= month 0) false
    (> month 12) false
    :else true
    )
)

(defn validYear [year]

  (cond 
    (<= year 0) false
    
    :else true
    )
)

(def dates '("4/4/2015" "-1/4/2015" "4/6/2015" "2/29/2015" "2/29/2016" "11/1/1973"
                "4/31/2006" ))

(def validDates (filter validDay dates))
(println validDates)

